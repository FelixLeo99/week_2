class QuestionObj {
  String image;
  String narration;
  String option_a;
  String option_b;
  String option_c;
  String option_d;
  String answer;

  QuestionObj(this.image, this.narration, this.option_a, this.option_b,
      this.option_c, this.option_d, this.answer);
}
