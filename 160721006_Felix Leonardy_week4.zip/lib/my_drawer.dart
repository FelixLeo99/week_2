import 'package:flutter/material.dart';

Widget myDrawer(BuildContext context) {
  return Drawer(
    elevation: 16.0,
    child: Column(
      children: <Widget>[
        const UserAccountsDrawerHeader(
            accountName: Text("xyz"),
            accountEmail: Text("xyz@gmail.com"),
            currentAccountPicture: CircleAvatar(
                backgroundImage: NetworkImage("https://i.pravatar.cc/150"))),
        ListTile(
            title: const Text("Inbox"),
            leading: const Icon(Icons.inbox),
            onTap: () {}),
        ListTile(
            title: const Text("My Basket"),
            leading: const Icon(Icons.shopping_basket),
            onTap: () {
              Navigator.pushNamed(context, '/basket');
            }),
        ListTile(
            title: const Text("About"),
            leading: const Icon(Icons.help),
            onTap: () {
              Navigator.pushNamed(context, '/about');
            }),
        ListTile(
            title: const Text("Student List"),
            leading: const Icon(Icons.list),
            onTap: () {
              Navigator.pushNamed(context, '/student_list');
            }),
        ListTile(
            title: const Text("Add Recipe"),
            leading: const Icon(Icons.add),
            onTap: () {
              Navigator.pushNamed(context, '/add_recipe');
            }),
      ],
    ),
  );
}
